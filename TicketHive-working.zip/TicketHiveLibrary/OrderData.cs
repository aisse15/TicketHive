
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace TicketHiveLibrary
{
    public class Order
    {
        public int OrderId { get; set; }
        public string CustomerName { get; set; }
        public DateTime OrderDate { get; set; }
        public string DeliveryAddress { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public decimal TotalAmount { get; set; }
        public string Status { get; set; }
        public bool Active { get; set; }
    }

    public class OrderData
    {
        private readonly DataConnection dataConnection;

        public OrderData()
        {
            dataConnection = new DataConnection();
        }

        public List<Order> GetAllOrders()
        {
            List<Order> orders = new List<Order>();

            using (SqlConnection connection = dataConnection.GetConnection())
            {
                connection.Open();
                SqlCommand command = new SqlCommand("usp_GetAllOrders", connection);
                command.CommandType = CommandType.StoredProcedure;

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        orders.Add(new Order
                        {
                            OrderId = (int)reader["OrderId"],
                            CustomerName = reader["CustomerName"].ToString(),
                            OrderDate = (DateTime)reader["OrderDate"],
                            DeliveryAddress = reader["DeliveryAddress"].ToString(),
                            ProductName = reader["ProductName"].ToString(),
                            Quantity = (int)reader["Quantity"],
                            TotalAmount = (decimal)reader["TotalAmount"],
                            Status = reader["Status"].ToString(),
                            Active = (bool)reader["Active"]
                        });
                    }
                }
            }
            return orders;
        }

        public Order GetOrderById(int orderId)
        {
            Order order = null;

            using (SqlConnection connection = dataConnection.GetConnection())
            {
                connection.Open();
                SqlCommand command = new SqlCommand("usp_GetOrderById", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@OrderId", orderId);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        order = new Order
                        {
                            OrderId = (int)reader["OrderId"],
                            CustomerName = reader["CustomerName"].ToString(),
                            OrderDate = (DateTime)reader["OrderDate"],
                            DeliveryAddress = reader["DeliveryAddress"].ToString(),
                            ProductName = reader["ProductName"].ToString(),
                            Quantity = (int)reader["Quantity"],
                            TotalAmount = (decimal)reader["TotalAmount"],
                            Status = reader["Status"].ToString(),
                            Active = (bool)reader["Active"]
                        };
                    }
                }
            }
            return order;
        }

        public void InsertOrder(Order order)
        {
            using (SqlConnection connection = dataConnection.GetConnection())
            {
                connection.Open();
                SqlCommand command = new SqlCommand("usp_InsertOrder", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CustomerName", order.CustomerName);
                command.Parameters.AddWithValue("@OrderDate", order.OrderDate);
                command.Parameters.AddWithValue("@DeliveryAddress", order.DeliveryAddress);
                command.Parameters.AddWithValue("@ProductName", order.ProductName);
                command.Parameters.AddWithValue("@Quantity", order.Quantity);
                command.Parameters.AddWithValue("@TotalAmount", order.TotalAmount);
                command.Parameters.AddWithValue("@Status", order.Status);
                command.Parameters.AddWithValue("@Active", order.Active);
                command.ExecuteNonQuery();
            }
        }

        public void UpdateOrder(Order order)
        {
            using (SqlConnection connection = dataConnection.GetConnection())
            {
                connection.Open();
                SqlCommand command = new SqlCommand("usp_UpdateOrder", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@OrderId", order.OrderId);
                command.Parameters.AddWithValue("@CustomerName", order.CustomerName);
                command.Parameters.AddWithValue("@OrderDate", order.OrderDate);
                command.Parameters.AddWithValue("@DeliveryAddress", order.DeliveryAddress);
                command.Parameters.AddWithValue("@ProductName", order.ProductName);
                command.Parameters.AddWithValue("@Quantity", order.Quantity);
                command.Parameters.AddWithValue("@TotalAmount", order.TotalAmount);
                command.Parameters.AddWithValue("@Status", order.Status);
                command.Parameters.AddWithValue("@Active", order.Active);
                command.ExecuteNonQuery();
            }
        }

        public void DeleteOrder(int orderId)
        {
            using (SqlConnection connection = dataConnection.GetConnection())
            {
                connection.Open();
                SqlCommand command = new SqlCommand("usp_DeleteOrder", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@OrderId", orderId);
                command.ExecuteNonQuery();
            }
        }
    }
}
