
using System.Configuration;
using System.Data.SqlClient;

namespace TicketHiveLibrary
{
    public class DataConnection
    {
        private readonly string connectionString;

        public DataConnection()
        {
            // Connection string directly integrated for now. 
            // You may later replace this by calling SQLConnect.exe securely if your module requires that step.
            connectionString = "Data Source=v00egd00002l.lec-admin.dmu.ac.uk;Initial Catalog=p2714843;User ID=p2714843;Password=teamabdirizaak123";
        }

        public SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}
